## -----------------------------------------------------------------------------
library(forcats)
library(xmap)

x <- factor(c("apple", "bear", "banana", "dear"))
levels <- ## new = "old" levels
  c(fruit = "apple", fruit = "banana") |>
  verify_named_all_values_unique()
forcats::fct_recode(x, !!!levels)

## ----error=TRUE---------------------------------------------------------------
mistake_levels <- c(fruit = "apple", fruit = "banana", veg = "banana") |>
  verify_named_all_values_unique()

## ----error=TRUE---------------------------------------------------------------
## mistakenly assign kate to another group
student_group_mistake <- list(GRP1 = c("kate", "jane", "peter"),
                           GRP2 = c("terry", "ben", "grace"),
                           GRP2 = c("cindy", "lucy", "kate" ))

student_list <- c("kate", "jane", "peter", "terry", "ben",
                  "grace", "cindy", "lucy", "alex")

student_group_mistake |>
  verify_named_matchset_values_exact(student_list)

## ----message=FALSE------------------------------------------------------------
library(xmap)
library(tibble)
library(dplyr)

## -----------------------------------------------------------------------------
# original data
v19_data <- tibble::tribble(
  ~v19, ~count,
  "1120", 300,
  "1121", 400,
  "1130", 200,
  "1200", 600
)

# valid crossmap
xmap_19to18 <- tibble::tribble(
  ~version19, ~version18, ~w19to18,
  # many-to-1 collapsing
  "1120", "A2", 1,
  "1121", "A2", 1,
  # 1-to-1 recoding
  "1130", "A3", 1,
  # 1-to-many redistribution
  "1200", "A4", 0.6,
  "1200", "A5", 0.4
) |>
  verify_links_as_xmap(from = version19, to = version18, weights = w19to18)

# transformed data
(v18_data <- dplyr::left_join(x = v19_data,
                      y = xmap_19to18,
                      by = c(v19 = "version19")) |>
  dplyr::mutate(new_count = count * w19to18) |>
  dplyr::group_by(version18) |>
  dplyr::summarise(v20_count = sum(new_count))
)

## -----------------------------------------------------------------------------
uk_shares <- tibble::tribble(
  ~key1, ~key2, ~shares,
  "UK, Channel Islands, Isle of Man", "Scotland", 0.1102047,
  "UK, Channel Islands, Isle of Man", "Wales", 0.02720333,
  "UK, Channel Islands, Isle of Man", "England", 0.862592
  )

uk_shares |>
  as_xmap_df(from = key1, to = key2, weights = shares, tol = 3e-08) |>
  print()

## ----error=TRUE---------------------------------------------------------------
uk_shares |>
  verify_links_as_xmap(key1, key2, shares)

