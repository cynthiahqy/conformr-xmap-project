## ----setup--------------------------------------------------------------------
library(xmap)

## -----------------------------------------------------------------------------
fruit_color <- c(apple = "green", strawberry = "red", banana = "yellow")
fruit_color |>
  verify_named_all_1to1() |>
  print()

## ----error=TRUE---------------------------------------------------------------
fruit_color_mistake <- c(fruit_color, pear = "green")

fruit_color_mistake |>
  verify_named_as_recode_unique()

## -----------------------------------------------------------------------------
student_groups <- list(GRP1 = c("kate", "jane", "peter"),
                       GRP2 = c("terry", "ben", "grace"),
                       GRP3 = c("cindy", "lucy", "alex" ))

## -----------------------------------------------------------------------------
student_groups |>
  verify_named_all_values_unique()

## ----error=TRUE---------------------------------------------------------------
## mistakenly assign kate to another group
student_group_mistake <- list(GRP1 = c("kate", "jane", "peter"),
                           GRP2 = c("terry", "ben", "grace"),
                           GRP2 = c("cindy", "lucy", "kate" ))

student_list <- c("kate", "jane", "peter", "terry", "ben", "grace", "cindy", "lucy", "alex")

student_group_mistake |>
  verify_named_matchset_values_exact(student_list)

## ----error=TRUE---------------------------------------------------------------
student_group_mistake |>
  verify_named_all_names_unique()

## ----error=TRUE---------------------------------------------------------------
group_links <- student_groups |>
  as_pairs_from_named(names_to = "group", values_to = "student") |>
  add_weights_unit()

## collapse xmap from students to groups
group_links |>
  verify_links_as_xmap(from = student, to = group, weights = weights)

## reverse doesn't work without adjusting the weights
group_links |>
  verify_links_as_xmap(from = group, to = student, weights = weights)

## -----------------------------------------------------------------------------
group_prize_links <- student_groups |>
  as_pairs_from_named("group", "student") |>
  dplyr::group_by(group) |>
  dplyr::mutate(prize_share = 1 / dplyr::n_distinct(student))

group_prize_links |>
  verify_links_as_xmap(from = group, to = student, weights = prize_share)

## -----------------------------------------------------------------------------
simple_links <- tibble::tribble(
  ~source, ~target, ~share,
  "equal", "EQUAL", 1,       # one-to-one
  "member_1", "GROUP", 1,    # one-FROM-many
  "member_2", "GROUP", 1,
  "whole", "PART_1", 0.3,    # one-to-many
  "whole", "PART_2", 0.6,
  "whole", "PART_3", 0.1
)

simple_xmap <- simple_links |>
  as_xmap_df(from = source, to = target, weights = share)

simple_xmap

## -----------------------------------------------------------------------------
iso_codes <- tibble::tribble(
              ~country, ~ISO2, ~ISO3, ~ISONumeric,
         "Afghanistan",          "AF",         "AFG",    "004",
             "Albania",          "AL",         "ALB",    "008",
             "Algeria",          "DZ",         "DZA",    "012",
      "American Samoa",          "AS",         "ASM",    "016",
             "Andorra",          "AD",         "AND",    "020"
      )

## -----------------------------------------------------------------------------
iso_codes |>
  verify_pairs_as_recode_unique(from = country, to = ISO2) |>
  print()

## -----------------------------------------------------------------------------
iso_xmap <- iso_codes |>
  add_weights_unit(weights_into = "weight") |>
  as_xmap_df(from = ISONumeric, to = ISO2, weights = weight)

## -----------------------------------------------------------------------------
print(iso_xmap)

## -----------------------------------------------------------------------------
iso_xmap |>
  xmap_to_named_vector()

## -----------------------------------------------------------------------------
iso_codes |>
  add_weights_unit(weights_into = "weight") |>
  as_xmap_df(from = ISO2, to = ISO3, weights = weight, .drop_extra = FALSE)

## -----------------------------------------------------------------------------
adm1_list <- tibble::tribble(
  ~ctr, ~adm1,
  "AU", "AU-NSW, AU-QLD, AU-SA, AU-TAS, AU-VIC, AU-WA, AU-ACT, AU-NT",
  "CA", "CA-AB, CA-BC, CA-MB, CA-NB, CA-NL, CA-NS, CA-ON, CA-PE, CA-QC, CA-SK, CA-NT, CA-NU, CA-YT"
)

## -----------------------------------------------------------------------------
agg_x <- adm1_list |> 
  dplyr::mutate(adm1 = stringr::str_split(adm1, ", ")) |>
  tidyr::unnest(cols = c(adm1))

agg_x

## -----------------------------------------------------------------------------
agg_xmap <- agg_x |>
  add_weights_unit(weights_into = "link") |>
  as_xmap_df(from = adm1, to = ctr, weights = link)

agg_xmap

## -----------------------------------------------------------------------------
state_data <- tibble::tribble(
                              ~state,    ~adm1,    ~Pop,
                   "New South Wales", "AU-NSW", 8153600,
                          "Victoria", "AU-VIC", 6613700,
                        "Queensland", "AU-QLD", 5322100,
                   "South Australia",  "AU-SA", 1820500,
                 "Western Australia",  "AU-WA", 2785300,
                          "Tasmania", "AU-TAS",  571500,
                "Northern Territory",  "AU-NT",  250600,
      "Australian Capital Territory", "AU-ACT",  456700
)

state_xmap <- state_data |>
  dplyr::mutate(ctr = "AU",
                adm1,
                share = Pop / sum(Pop)) |>
  as_xmap_df(from = ctr, to = adm1, weights = share)

state_xmap

## -----------------------------------------------------------------------------
canada_recode <- tibble::tibble(
  NAICS1997      = "212210", 
  NAICS1997_desc = "Iron Ore Mining",
  ISIC3          = "C1310",
  ISIC3_desc    = "Mining of iron ores"
)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(canada_recode)

## -----------------------------------------------------------------------------
canada_agg <- tibble::tribble(
  ~NAICS1997, ~NAICS1997_desc, ~ISIC3, ~ISIC3_desc, ~Link,
  "311320", "Chocolate and Confectionery Manufacturing from Cacao Beans", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Chocolate and confectionery, made from cacao beans",
  "311330", "Confectionery Manufacturing from Purchased Chocolate", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Confectionery, made from purchased chocolate",
  "311340", "Non-Chocolate Confectionery Manufacturing", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Non-chocolate confectionery, manufacturing"
)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(canada_agg)

## -----------------------------------------------------------------------------
canada_split <- tibble::tribble(
  ~NAICS1997, ~NAICS1997_desc, ~ISIC3, ~ISIC3_desc, ~Link,
  "483213", "Inland Water Transportation (except by Ferries)", "I6110 *", "Sea and coastal water transport", "Intracoastal water transportation",
  "483213", "Inland Water Transportation (except by Ferries)", "I6120 *", "Inland water transport", "Inland water transportation (except ferries)"
)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(canada_split)

## -----------------------------------------------------------------------------
canada_unit <- canada_agg |>
  # remove the partial flag (*)
  dplyr::mutate(ISIC3 = stringr::str_remove(ISIC3, " \\*")) |>
  dplyr::select(-Link) |>
  # bind the links together and add weights
  dplyr::bind_rows(canada_recode) |>
  dplyr::mutate(share = 1)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(canada_unit)

## -----------------------------------------------------------------------------
canada_frac <- canada_split |>
  dplyr::mutate(ISIC3 = stringr::str_remove(ISIC3, " \\*")) |>
  dplyr::select(-Link) |>
  dplyr::mutate(share = dplyr::case_when(ISIC3 == "I6110" ~ 0.33,
                                  ISIC3 == "I6120" ~ 0.67,
                                  T ~ NA_real_))

## -----------------------------------------------------------------------------
canada_xmap <- dplyr::bind_rows(canada_unit, canada_frac) |>
  as_xmap_df(from = NAICS1997, to = ISIC3, weights = share)

print(canada_xmap)

## ----error=TRUE---------------------------------------------------------------
dplyr::bind_rows(canada_unit, canada_frac) |>
  as_xmap_df(from = ISIC3, to = NAICS1997, weights = share)

## -----------------------------------------------------------------------------
print(iso_xmap)

## -----------------------------------------------------------------------------
iso_xmap |>
  xmap_reverse()

## -----------------------------------------------------------------------------
state_xmap |>
  xmap_drop_extra()

## -----------------------------------------------------------------------------
state_xmap |>
  xmap_reverse(weights_into = "agg_w") |>
  xmap_drop_extra()

