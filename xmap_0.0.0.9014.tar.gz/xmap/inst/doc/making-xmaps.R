## -----------------------------------------------------------------------------
library(xmap)

simple_x <- tibble::tribble(
  ~source, ~target, ~share,
  "equal", "EQUAL", 1,       # one-to-one
  "member_1", "GROUP", 1,    # many-to-one
  "member_2", "GROUP", 1,
  "whole", "PART_1", 0.3,    # one-to-many
  "whole", "PART_2", 0.6,
  "whole", "PART_3", 0.1
)

simple_xmap <- simple_x |>
  as_xmap_df(from = source, to = target, weights = share)

simple_xmap

## -----------------------------------------------------------------------------
iso_codes <- tibble::tribble(
              ~country, ~ISO2, ~ISO3, ~ISONumeric,
         "Afghanistan",          "AF",         "AFG",    "004",
             "Albania",          "AL",         "ALB",    "008",
             "Algeria",          "DZ",         "DZA",    "012",
      "American Samoa",          "AS",         "ASM",    "016",
             "Andorra",          "AD",         "AND",    "020"
      )

## -----------------------------------------------------------------------------
iso_xmap <- iso_codes |>
  dplyr::mutate(link = 1) |>
  as_xmap_df(from = ISONumeric, to = ISO2, weights = link)

## -----------------------------------------------------------------------------
print(iso_xmap)

## -----------------------------------------------------------------------------
iso_codes |>
  dplyr::mutate(link = 1) |>
  as_xmap_df(from = ISO2, to = ISO3, weights = link)

## -----------------------------------------------------------------------------
adm1_list <- tibble::tribble(
  ~ctr, ~adm1,
  "AU", "AU-NSW, AU-QLD, AU-SA, AU-TAS, AU-VIC, AU-WA, AU-ACT, AU-NT",
  "CA", "CA-AB, CA-BC, CA-MB, CA-NB, CA-NL, CA-NS, CA-ON, CA-PE, CA-QC, CA-SK, CA-NT, CA-NU, CA-YT"
)

## -----------------------------------------------------------------------------
agg_x <- adm1_list |> 
  dplyr::mutate(adm1 = stringr::str_split(adm1, ", ")) |>
  tidyr::unnest(cols = c(adm1))

agg_x

## -----------------------------------------------------------------------------
agg_xmap <- agg_x |>
  dplyr::mutate(link = 1) |>
  as_xmap_df(from = adm1, to = ctr, weights = link)

agg_xmap

## -----------------------------------------------------------------------------
state_data <- tibble::tribble(
                              ~state,    ~adm1,    ~Pop,
                   "New South Wales", "AU-NSW", 8153600,
                          "Victoria", "AU-VIC", 6613700,
                        "Queensland", "AU-QLD", 5322100,
                   "South Australia",  "AU-SA", 1820500,
                 "Western Australia",  "AU-WA", 2785300,
                          "Tasmania", "AU-TAS",  571500,
                "Northern Territory",  "AU-NT",  250600,
      "Australian Capital Territory", "AU-ACT",  456700
)

state_xmap <- state_data |>
  dplyr::mutate(ctr = "AU",
                adm1,
                share = Pop / sum(Pop)) |>
  as_xmap_df(from = ctr, to = adm1, weights = share)

state_xmap

## -----------------------------------------------------------------------------
canada_recode <- tibble::tibble(
  NAICS1997      = "212210", 
  NAICS1997_desc = "Iron Ore Mining",
  ISIC3          = "C1310",
  ISIC3_desc    = "Mining of iron ores"
)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(canada_recode)

## -----------------------------------------------------------------------------
canada_agg <- tibble::tribble(
  ~NAICS1997, ~NAICS1997_desc, ~ISIC3, ~ISIC3_desc, ~Link,
  "311320", "Chocolate and Confectionery Manufacturing from Cacao Beans", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Chocolate and confectionery, made from cacao beans",
  "311330", "Confectionery Manufacturing from Purchased Chocolate", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Confectionery, made from purchased chocolate",
  "311340", "Non-Chocolate Confectionery Manufacturing", "D1543 *", "Manufacture of cocoa, chocolate and sugar confectionery", "Non-chocolate confectionery, manufacturing"
)

## ----echo=FALSE---------------------------------------------------------------
canada_agg

## -----------------------------------------------------------------------------
canada_split <- tibble::tribble(
  ~NAICS1997, ~NAICS1997_desc, ~ISIC3, ~ISIC3_desc, ~Link,
  "483213", "Inland Water Transportation (except by Ferries)", "I6110 *", "Sea and coastal water transport", "Intracoastal water transportation",
  "483213", "Inland Water Transportation (except by Ferries)", "I6120 *", "Inland water transport", "Inland water transportation (except ferries)"
)

## ----echo=FALSE---------------------------------------------------------------
canada_split 

## -----------------------------------------------------------------------------
canada_unit <- canada_agg |>
  # remove the partial flag (*)
  dplyr::mutate(ISIC3 = stringr::str_remove(ISIC3, " \\*")) |>
  dplyr::select(-Link) |>
  # bind the links together and add weights
  dplyr::bind_rows(canada_recode) |>
  dplyr::mutate(share = 1)

canada_unit

## -----------------------------------------------------------------------------
canada_frac <- canada_split |>
  dplyr::mutate(ISIC3 = stringr::str_remove(ISIC3, " \\*")) |>
  dplyr::select(-Link) |>
  dplyr::mutate(share = dplyr::case_when(ISIC3 == "I6110" ~ 0.33,
                                  ISIC3 == "I6120" ~ 0.67,
                                  T ~ NA_real_))

## -----------------------------------------------------------------------------
canada_xmap <- dplyr::bind_rows(canada_unit, canada_frac) |>
  as_xmap_df(from = NAICS1997, to = ISIC3, weights = share)

print(canada_xmap)

## ----error=TRUE---------------------------------------------------------------
dplyr::bind_rows(canada_unit, canada_frac) |>
  as_xmap_df(from = ISIC3, to = NAICS1997, weights = share)

## -----------------------------------------------------------------------------
print(iso_xmap)

## -----------------------------------------------------------------------------
iso_xmap |>
  xmap_reverse()

