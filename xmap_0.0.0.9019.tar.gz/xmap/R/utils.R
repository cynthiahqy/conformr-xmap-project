# Generated from create-xmap.Rmd: do not edit by hand

#' Defaults for NULL values
#' @name op-null-default
#' @keywords internal
`%||%` <- function(x, y) if (is.null(x)) y else x
