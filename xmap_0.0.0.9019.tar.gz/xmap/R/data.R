# Generated from create-xmap.Rmd: do not edit by hand

#' Mock objects for the `xmap` package
#' 
#' A list of mock objects for experimenting with functions
#' in the `xmap` package.
#' 
#' @format ## `mock`
#' A list with :
#' \describe{
#'  \item{recode_vect, collapse_list}{Named vector and list for conversion into node pairs}
#'  \item{xmap}
#'  }
#' @source Package authors
