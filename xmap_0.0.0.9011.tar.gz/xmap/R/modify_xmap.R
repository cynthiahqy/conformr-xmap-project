modify_xmap_df <- function(xmap_df, col_from = NULL, col_to = NULL, col_weights = NULL){
  stopifnot(inherits(xmap_df, "xmap_df"))
  
  x_attrs <- attributes(xmap_df)
  col_from <- col_from %||% x_attrs$col_from
  col_to <- col_to %||% x_attrs$col_to
  col_weights <- col_weights %||% x_attrs$col_weights
  
  col_strings <- c(col_from, col_to, col_weights)
  df_check_cols(xmap_df, col_strings)
  
  df <- as.data.frame(xmap_df)
  col_order <- c(col_strings, setdiff(names(df), col_strings))
  df <- df[col_order]
  xmap <- new_xmap_df(df, col_from, col_to, col_weights)
  validate_xmap_df(xmap)

  return(xmap)
}
