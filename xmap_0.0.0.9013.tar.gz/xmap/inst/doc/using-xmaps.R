## -----------------------------------------------------------------------------
library(xmap)

agg_map <- data.frame(ctr = "AU",
                      adm1 = c("AU-NSW", "AU-QLD", "AU-SA", "AU-TAS", "AU-VIC", "AU-WA", "AU-ACT", "AU-NT"),
                      link = 1) |>
  as_xmap_df(adm1, ctr, link)

## -----------------------------------------------------------------------------
state_data <- tibble::tribble(
                              ~state,    ~adm1,    ~Pop,
                   "New South Wales", "AU-NSW", 8153600,
                          "Victoria", "AU-VIC", 6613700,
                        "Queensland", "AU-QLD", 5322100,
                   "South Australia",  "AU-SA", 1820500,
                 "Western Australia",  "AU-WA", 2785300,
                          "Tasmania", "AU-TAS",  571500,
                "Northern Territory",  "AU-NT",  250600,
      "Australian Capital Territory", "AU-ACT",  456700
)

## -----------------------------------------------------------------------------
dplyr::left_join(state_data, agg_map, by = c("adm1")) |>
  dplyr::mutate(x_pop = Pop * link) |>
  dplyr::group_by(ctr) |>
  dplyr::summarise(agg_pop = sum(x_pop))

