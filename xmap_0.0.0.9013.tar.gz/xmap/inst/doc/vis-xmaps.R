## ----message=FALSE------------------------------------------------------------
library(ggplot2)
library(dplyr)
library(ggbump)
library(xmap)

## -----------------------------------------------------------------------------
anzsco_cw <- tibble::tribble(
      ~anzsco22,                        ~anzsco22_descr, ~isco8, ~partial,                                         ~isco8_descr,
       "111111", "Chief Executive or Managing Director", "1112",      "p",                        "Senior government officials",
       "111111", "Chief Executive or Managing Director", "1114",      "p", "Senior officials of special-interest organizations",
       "111111", "Chief Executive or Managing Director", "1120",      "p",            "Managing directors and chief executives",
       "111211",            "Corporate General Manager", "1112",      "p",                        "Senior government officials",
       "111211",            "Corporate General Manager", "1114",      "p", "Senior officials of special-interest organizations",
       "111211",            "Corporate General Manager", "1120",      "p",            "Managing directors and chief executives",
       "111212",         "Defence Force Senior Officer", "0110",      "p",                 "Commissioned armed forces officers",
       "111311",          "Local Government Legislator", "1111",      "p",                                        "Legislators",
       "111312",                 "Member of Parliament", "1111",      "p",                                        "Legislators",
       "111399",                      "Legislators nec", "1111",      "p",                                        "Legislators"
      )

links <- anzsco_cw |>
  dplyr::group_by(anzsco22) |>
  dplyr::summarise(n_dest = dplyr::n_distinct(isco8)) |>
  dplyr::ungroup() |>
  dplyr::transmute(anzsco22, weight = 1/n_dest) |>
  dplyr::left_join(anzsco_cw, by = "anzsco22")

## get code tables
table_anzsco <- anzsco_cw |>
  dplyr::distinct(anzsco22, anzsco22_descr)
table_isco8 <- anzsco_cw |>
  dplyr::distinct(isco8, isco8_descr)

## make xmap
anzsco_xmap <- links |>
  as_xmap_df(anzsco22, isco8, weight)

## -----------------------------------------------------------------------------
print(anzsco_xmap)

## ----message=FALSE------------------------------------------------------------
plt_xmap_bigraph <- function(x, ...) {
  stopifnot(is_xmap_df(x))
  x_attrs <- attributes(x)
  edges_short <- tibble::as_tibble(x)
  
  ## generate out link type
  style_out_case <- tibble::tribble(
    ~out_case, ~line_type, ~font_type,
    "unit_out", "solid", "bold",
    "frac_out", "dashed", "italic")
  df_out_style <- edges_short |>
    dplyr::mutate(out_case = dplyr::case_when(.data[[x_attrs$col_weights]] == 1 ~ "unit_out",
                                              .data[[x_attrs$col_weights]] < 1 ~ "frac_out")) |>
    dplyr::left_join(style_out_case,
              by = "out_case") |>
    dplyr::ungroup()
  
  ## attach node positions
  from_nodes <- tibble::tibble(from_set = x_attrs$from_set) |>
    dplyr::mutate(from_y = dplyr::row_number())
  to_nodes <- tibble::tibble(to_set = unique(x[[x_attrs$col_to]])) |>
    dplyr::mutate(to_y = dplyr::row_number() - 1 + 0.5)
  df_gg <- df_out_style |>
    dplyr::left_join(from_nodes, by = setNames("from_set", x_attrs$col_from)) |>
    dplyr::left_join(to_nodes, by = setNames("to_set", x_attrs$col_to)) |>
    dplyr::mutate(from_x = 0,
                  to_x = 5) |>
    dplyr::mutate(idx = dplyr::row_number())
  
  ## build ggplot
  ggplot2::ggplot(data = df_gg,
                  aes(x = from_x, xend = to_x,
                      y = from_y, yend = to_y,
                      group = idx)) +
    ## edges
    ggbump::geom_sigmoid(aes(linetype = I(line_type))) +
    ggplot2::geom_label(data = dplyr::filter(df_gg, out_case == "unit_out"),
             aes(x = (from_x + to_x) / 4,
                 y = from_y,
                 label = round(.data[[x_attrs$col_weights]], 2))) +
    ggplot2::geom_label(data = dplyr::filter(df_gg, out_case == "frac_out"),
             aes(x = (((from_x + to_x) / 2) + to_x) / 2,
                 y = to_y,
                 label = round(.data[[x_attrs$col_weights]], 2))) +
    ## from nodes
    ggplot2::geom_text(aes(x = from_x - 0.5, y = from_y,
                           label = .data[[x_attrs$col_from]],
                           fontface=I(font_type)),
                      ## drop idx groups to avoid duplicate labels
                      stat = "unique", inherit.aes = FALSE) +
    ## to nodes
    ggplot2::geom_label(aes(x = to_x + 0.5, y = to_y, 
                            label = .data[[x_attrs$col_to]]),
                        fill = "black",
                        alpha = 0.1) +
    ggplot2::scale_y_reverse() +
    ggplot2::theme_minimal() +
    theme(legend.position = "bottom",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_blank(),
        plot.background = element_rect(fill = "white")) +
    labs(x = NULL, y = NULL)
}

## ----message=FALSE, echo=FALSE------------------------------------------------
gg_bigraph <- anzsco_xmap |>
  plt_xmap_bigraph()

# print bigraph and code tables
gg_bigraph

## ----message=FALSE, echo=FALSE------------------------------------------------
knitr::kable(list(table_anzsco, table_isco8))

## -----------------------------------------------------------------------------
edges <- tribble(~ctr, ~ctr2, ~split,
                 "BLX", "BEL", 0.5,
                 "BLX", "LUX", 0.5,
                 "E.GER", "DEU", 1,
                 "W.GER", "DEU", 1)

## ----xmap-as-matrix-----------------------------------------------------------
plt_xmap_ggmatrix <- function(x, ...){
  stopifnot(is_xmap_df(x))
  x_attrs <- attributes(x)
  edges_complete <- tibble::as_tibble(x) |> 
    tidyr::complete(.data[[x_attrs$col_from]], .data[[x_attrs$col_to]])
  
  ## add link-out type
  gg_df <- edges_complete |>
    dplyr::mutate(out_case = dplyr::case_when(.data[[x_attrs$col_weights]] == 1 ~ "one-to-one",
                                              .data[[x_attrs$col_weights]] < 1 ~ "one-to-many",
                                              is.na(.data[[x_attrs$col_weights]]) ~ "none")
                  )
  
  ## make plot
  gg_df |> ggplot(aes(x=.data[[x_attrs$col_to]],
                      y=.data[[x_attrs$col_from]])) +
    geom_tile(aes(fill=out_case), col="grey") +
    scale_y_discrete(limits=rev) +
    scale_x_discrete(position='top') +
    scale_fill_brewer() +
    coord_fixed()  +
    labs(x = x_attrs$col_to, y = x_attrs$col_from, fill="Outgoing Link Type") +
    theme_minimal() +
    geom_text(data = dplyr::filter(gg_df, !is.na(.data[[x_attrs$col_weights]])), aes(label=round(.data[[x_attrs$col_weights]], 2))) +
    theme(legend.position = "bottom",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()
    )
}

## -----------------------------------------------------------------------------
plt_xmap_ggmatrix(anzsco_xmap)

