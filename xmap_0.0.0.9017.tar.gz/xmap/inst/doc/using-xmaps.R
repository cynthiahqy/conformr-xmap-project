## ----echo=FALSE---------------------------------------------------------------
state_data <- tibble::tribble(
                              ~State,    ~`Population (est. 30 Jun 2022)`,
                   "New South Wales", 8153600,
                          "Victoria", 6613700,
                        "Queensland", 5322100,
                   "South Australia", 1820500,
                 "Western Australia", 2785300,
                          "Tasmania",  571500,
                "Northern Territory",  250600,
      "Australian Capital Territory",  456700
)

total_pop_ex <- round(sum(state_data$`Population (est. 30 Jun 2022)`) / 10^6, 2)

## ----echo=FALSE---------------------------------------------------------------
knitr::kable(state_data, caption = "Australian population by State (excl. Other Territories)")

## -----------------------------------------------------------------------------
library(xmap)
## define crossmap
abc_xmap <- tibble::tribble(
      ~origin, ~dest, ~link,
          "a",  "AA",     1,
          "b",  "AA",     1,
          "c",  "AA",     1,
          "d",  "BB",     1,
          "e",  "CC",     1,
          "f",  "DD",   0.3,
          "f",  "EE",   0.3,
          "f",  "FF",   0.4
      ) |>
  as_xmap_df(from = origin, to = dest, link)

## convert to matrix
b_mtx <- xmap_to_matrix(abc_xmap, sparse = FALSE)
b_mtx

## -----------------------------------------------------------------------------
## define example data
x <- matrix(rep_len(100, nrow(b_mtx)))
dimnames(x) <- list(row.names(b_mtx), "x")

## apply transformation
y <- t(b_mtx) %*% x

## print
matlib::printMatEqn(`B'` = t(b_mtx), x, "=", y)

## ---- attr.source='.numberLines'----------------------------------------------
y <- list()

y$AA = x["a", ] + x["b", ] + x["c", ]
y$BB = x["d", ]
y$CC = x["c", ]
y$DD = 0.3 * x["f", ]
y$EE = 0.2 * x["f", ]
y$FF = 0.4 * x["f", ]

y |> as.matrix()

## -----------------------------------------------------------------------------
baby_pets <- c("puppy", "kitten", "chick")
adult_pets <- c("dog", "cat", "bird")

pet_xmap <- tibble::tibble(baby = baby_pets,
                           adult = adult_pets,
                           link = 1)

## some data on pets
pet_df <- tibble::tibble(obs_id = 1:5, pet_type = sample(baby_pets, 5, replace = TRUE), bool = 1)

## categorical variable format
pet_df

## the format needed to use apply_xmap()
pet_df |> tidyr::pivot_wider(names_from = "pet_type", values_from = "bool") |>
  tidyr::pivot_longer(cols=dplyr::all_of(baby_pets)) |>
  tidyr::replace_na(list(value = 0))

## -----------------------------------------------------------------------------
## table 5: https://www.abs.gov.au/statistics/labour/jobs/jobs-australia/2015-16-2019-20
tibble::tribble(
                                  ~Occupation, ~`Male.('000.persons)`, ~`Female.('000.persons)`,
                                   "Managers",                  934.4,                    668.5,
                              "Professionals",                 1190.9,                   1542.2,
             "Technicians and trades workers",                 1229.7,                      225,
     "Community and personal service workers",                    443,                    998.1,
        "Clerical and administrative workers",                  373.5,                   1203.7,
                              "Sales workers",                  382.6,                    651.4,
            "Machinery operators and drivers",                  621.3,                     81.3,
                                  "Labourers",                  815.5,                      437
     ) |> knitr::kable()

## -----------------------------------------------------------------------------
## Table: All employees, average weekly total cash earnings - industry
## https://www.abs.gov.au/statistics/labour/earnings-and-working-conditions/employee-earnings-and-hours-australia/may-2021
tibble::tribble(
                                              ~industry,  ~avg_weekly_earnings,
                                               "Mining", "2,798.40",
                                        "Manufacturing", "1,457.40",
           "Electricity, gas, water and waste services", "2,060.90",
                                         "Construction", "1,600.40",
                                      "Wholesale trade", "1,468.20",
                                         "Retail trade",   "864.50",
                      "Accommodation and food services",   "664.70",
                    "Transport, postal and warehousing", "1,587.70",
             "Information media and telecommunications", "1,797.40",
                       "Finance and insurance services", "1,990.40",
              "Rental, hiring and real estate services", "1,381.70",
      "Professional, scientific and technical services", "1,911.30",
                  "Administrative and support services", "1,234.50",
                     "Public administration and safety", "1,745.40",
                               "Education and training", "1,374.80",
                    "Health care and social assistance", "1,287.40",
                         "Arts and recreation services", "1,032.90",
                                       "Other services", "1,043.10",
                                       "**All industries**", "**1,394.10**"
) |> knitr::kable()

## -----------------------------------------------------------------------------
origin_tidy_sub <- tibble::tribble(
  ~country, ~year, ~sector, ~subsector, ~output,
  "AU", 2012, "AGR", "FISH", 3983,
  "AU", 2012, "AGR", "LIVE", 432,
  "AU", 2013, "AGR", "FISH", 3983,
  "AU", 2013, "AGR", "LIVE", NA,
)

origin_tidy_sub

## -----------------------------------------------------------------------------
origin_tidy_sec <- origin_tidy_sub |>
  dplyr::group_by(country, year, sector) |>
  dplyr::summarise(output = sum(output, na.rm = TRUE), .groups = "drop")

origin_tidy_sec

## -----------------------------------------------------------------------------
library(xmap)

agg_map <- data.frame(ctr = "AU",
                      adm1 = c("AU-NSW", "AU-QLD", "AU-SA", "AU-TAS", "AU-VIC", "AU-WA", "AU-ACT", "AU-NT"),
                      link = 1) |>
  as_xmap_df(adm1, ctr, link)

## -----------------------------------------------------------------------------
state_data <- tibble::tribble(
                              ~state,    ~adm1,    ~Pop,
                   "New South Wales", "AU-NSW", 8153600,
                          "Victoria", "AU-VIC", 6613700,
                        "Queensland", "AU-QLD", 5322100,
                   "South Australia",  "AU-SA", 1820500,
                 "Western Australia",  "AU-WA", 2785300,
                          "Tasmania", "AU-TAS",  571500,
                "Northern Territory",  "AU-NT",  250600,
      "Australian Capital Territory", "AU-ACT",  456700
)

## -----------------------------------------------------------------------------
dplyr::left_join(state_data, agg_map, by = c("adm1")) |>
  dplyr::mutate(x_pop = Pop * link) |>
  dplyr::group_by(ctr) |>
  dplyr::summarise(agg_pop = sum(x_pop))

## -----------------------------------------------------------------------------
raw_abs_pop <-     tibble::tribble(
                                       ~...1,     ~X2002,     ~X2012,     ~X2022,
                                          NA,      "no.",      "no.",      "no.",
                 "Australia–at 30 September",         NA,         NA,         NA,
                           "New South Wales",  "6580807",  "7304244",  "8153584",
                                  "Victoria",  "4817774",  "5651091",  "6613727",
                                "Queensland",  "3653123",  "4568687",  "5322058",
                           "South Australia",  "1511567",  "1656725",  "1820530",
                         "Western Australia",  "1928512",  "2425507",  "2785312",
                                  "Tasmania",   "474152",   "511724",   "571517",
                        "Northern Territory",   "202251",   "235915",   "250635",
              "Australian Capital Territory",   "324627",   "376539",   "456652",
                         "Other Territories",         NA,         NA,         NA,
                      "Jervis Bay Territory",      "464",      "380",      "312",
             "Territory of Christmas Island",     "1365",     "2107",     "1781",
      "Territory of Cocos (Keeling) Islands",      "568",      "546",      "614",
                            "Norfolk Island",        "0",        "0",     "2213",
                   "Total Other Territories",     "2397",     "3033",     "4920",
                           "Total Australia", "19495210", "22733465", "25978935"
      )

## -----------------------------------------------------------------------------
abs_pop <- raw_abs_pop |>
  dplyr::slice(3:dplyr::n()) |>
  dplyr::rename(area = `...1`)

knitr::kable(abs_pop)

## -----------------------------------------------------------------------------
abs_split <- split(abs_pop, stringr::str_detect(abs_pop$area, "Total|Other Territories", negate = TRUE))
state_pop <- abs_split$`TRUE`

knitr::kable(state_pop)

## -----------------------------------------------------------------------------
state_nom <- state_pop |>
  tidyr::pivot_longer(cols = -area, names_to = "year", values_to = "population") |>
  dplyr::select(year, dplyr::everything()) |>
  dplyr::arrange(year)

knitr::kable(state_nom)

